<?php
$aliases['d6'] = array(
  'root' => '/var/www/d6.viktor-skelia/public_html/',
  'uri' => 'd6.viktor-skelia',
);
